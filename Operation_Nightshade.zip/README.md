Name : Operation Nightshade

Description : 

A workstation belonging to a departing employee (**D. Voss**) is suspected of data exfiltration immediately preceding their last day at the company. 

The Blue Team succeeded in seizing three forensic artifacts from the workstation environment:

1. `nightshade.pcapng` — Network packet capture collected from the workstation's switch port over an exfiltration window.
2. `workstation.dd` — Raw ext4 disk image of the workstation drive.
3. `memdump.raw` — Memory dump captured while a suspicious background exfiltration agent process was active on the host.

Your task is to reconstruct the multi-stage exfiltration chain and recover the secret flag. 

---
## Flag Format

```
KaliTeam{<fragment1>_<fragment2>_<fragment3>_<fragment4>}
```

